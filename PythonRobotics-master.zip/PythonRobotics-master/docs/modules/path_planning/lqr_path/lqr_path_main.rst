LQR based path planning
-----------------------

A sample code using LQR based path planning for double integrator model.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/PathPlanning/LQRPlanner/animation.gif?raw=true
