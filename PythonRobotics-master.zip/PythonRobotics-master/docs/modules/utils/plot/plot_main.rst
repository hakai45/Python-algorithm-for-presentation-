.. _plot_utils:

Plotting Utilities
-------------------

This module contains a number of utility functions for plotting data.

.. _plot_curvature:

plot_curvature
~~~~~~~~~~~~~~~

.. autofunction:: utils.plot.plot_curvature

.. image:: curvature_plot.png

