Ensamble Kalman Filter Localization
-----------------------------------

.. figure:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Localization/ensamble_kalman_filter/animation.gif

This is a sensor fusion localization with Ensamble Kalman Filter(EnKF).

