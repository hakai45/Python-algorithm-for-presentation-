Object shape recognition using circle fitting
---------------------------------------------

This is an object shape recognition using circle fitting.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Mapping/circle_fitting/animation.gif

The blue circle is the true object shape.

The red crosses are observations from a ranging sensor.

The red circle is the estimated object shape using circle fitting.

